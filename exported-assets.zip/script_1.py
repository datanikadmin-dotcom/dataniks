from pathlib import Path
print(Path('/home/oai/output/datanikslab-final-share.zip').exists())
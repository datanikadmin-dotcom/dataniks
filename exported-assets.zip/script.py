from pathlib import Path
import zipfile
root = Path('/home/oai/output/datanikslab-premium-redesign')
zip_path = Path('/home/oai/output/datanikslab-final-share.zip')
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in root.iterdir():
        z.write(p, arcname=p.name)
print(zip_path)

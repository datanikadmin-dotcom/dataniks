from pathlib import Path
print('ready to share')